package api;

public interface ContadorTDA {
    void inicializarContador();
    void Contar();
    void Descontar();
    void Reiniciar();
    int Mostrar();
}

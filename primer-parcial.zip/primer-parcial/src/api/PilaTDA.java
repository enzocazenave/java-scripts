package api;

public interface PilaTDA {
    void InicializarPila();
    void Apilar(int x);
    void Desapilar();
    int Tope();
    boolean PilaVacia();
}